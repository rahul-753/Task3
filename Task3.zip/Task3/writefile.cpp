#include<iostream>
using namespace std;
#include<fstream>
int main(){

    ofstream file("myfile.txt");

    if(file.is_open()){
        file<<"I am creating new file for linked..."<<endl;
        file<<"I am happy to share that I have joined Happieloop Technology... ";
        file.close();
    }
    else{
        file<<"File Not Open"<<endl;
    }

    return 0;
}