#include<iostream>
using namespace std;
#include<fstream>
int main(){

    ifstream file("myfile.txt");
    string str;

    if(file.is_open()){
        while (getline(file,str))
        {
            cout<<str<<endl;
        }
        file.close();
    }
    else{
        cout<<"File Not Open";
    }

    return 0;
}